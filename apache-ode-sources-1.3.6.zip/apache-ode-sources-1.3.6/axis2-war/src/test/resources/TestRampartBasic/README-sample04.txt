Message integrity and non-repudiation with signature

Both client and servce are configured to sign the outgoing message and to verify
the signature of the incoming message using their key pairs.
    - See the "OutflowSecurity" and "InflowSecurity" parameters in the 
      client.axis2.xml and serivces.xml files
    
