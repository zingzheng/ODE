

How does TestRampartBasic bundle work?
========================================

please refer to TestRampartPolicy/readme.txt
 