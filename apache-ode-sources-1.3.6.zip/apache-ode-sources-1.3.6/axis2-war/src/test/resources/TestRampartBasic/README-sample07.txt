Encrypt and sign messages

Both client and servce are configured to first encrypt and then sign the 
outgoing message and to verify and decrypt the incoming message using their 
key pairs.
    - See the "OutflowSecurity" and "InflowSecurity" parameters in the 
      client.axis2.xml and serivces.xml files
    
