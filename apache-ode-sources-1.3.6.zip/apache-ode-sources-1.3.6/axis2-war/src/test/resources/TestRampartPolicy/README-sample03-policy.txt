Sign and Encrypt messages

An AsymmetricBinding is used. Entire headers and body to be signed. 
EncryptionParts specifies the Body to be encrypted.

Algorithm suite is TripleDesRsa15

Note that {http://ws.apache.org/rampart/policy}RampartConfig assertion provides
additional information required to secure the message.